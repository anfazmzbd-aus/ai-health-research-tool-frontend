'use client'

import type { OutputMode } from '@/lib/types'

interface Props {
  value: OutputMode
  onChange: (mode: OutputMode) => void
}

const MODES: { value: OutputMode; label: string; desc: string }[] = [
  { value: 'patient',  label: 'Patient',  desc: 'Plain English' },
  { value: 'balanced', label: 'Balanced', desc: 'Clear & accurate' },
  { value: 'clinical', label: 'Clinical', desc: 'Medical detail' },
]

export function ModeToggle({ value, onChange }: Props) {
  return (
    <div className="flex gap-1 p-1 bg-gray-100 rounded-lg">
      {MODES.map((m) => (
        <button
          key={m.value}
          onClick={() => onChange(m.value)}
          className={`flex-1 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
            value === m.value
              ? 'bg-white text-gray-900 shadow-sm'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          <div>{m.label}</div>
          <div className="text-[10px] font-normal opacity-60 hidden sm:block">{m.desc}</div>
        </button>
      ))}
    </div>
  )
}
