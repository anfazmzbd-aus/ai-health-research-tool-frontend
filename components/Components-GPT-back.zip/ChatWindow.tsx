'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { v4 as uuidv4 } from 'uuid'
import type { Message, AppSettings, MultimodalAnalysis } from '@/lib/types'
import { streamChat, runResearch } from '@/lib/api'

import { MessageBubble } from './MessageBubble'
import { ModeToggle } from './ModeToggle'
import { DepthToggle } from './DepthToggle'
import { FileUpload } from './FileUpload'
import { DisclaimerBanner } from './DisclaimerBanner'

const WELCOME: Message = {
  id: 'welcome',
  role: 'assistant',
  content: `Welcome to the AI Health Research Tool.
I can help you:
- Answer health and medical questions with cited sources
- Analyse lab reports and medical documents you upload
- Search live PubMed literature and clinical trials
- Generate deep research reports on complex medical topics

*Try asking:* "What are normal cholesterol levels?" or upload a lab report to get started.`,
  citations: [],
  timestamp: Date.now(),
}

export function ChatWindow() {
  const [messages, setMessages] = useState<Message[]>([WELCOME])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)

  const [settings, setSettings] = useState<AppSettings>({
    mode: 'balanced',
    depth: 'quick',
    sessionId: uuidv4(),
  })

  const [fileAnalysis, setFileAnalysis] = useState<MultimodalAnalysis | null>(null)
  const [showUpload, setShowUpload] = useState(false)

  const bottomRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)
  const abortRef = useRef<AbortController | null>(null)

  // Auto scroll
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const addMessage = (msg: Omit<Message, 'id' | 'timestamp'>): string => {
    const id = uuidv4()
    setMessages(prev => [...prev, { ...msg, id, timestamp: new Date() }])
    return id
  }

  const updateMessage = (id: string, patch: Partial<Message>) => {
    setMessages(prev => prev.map(m => (m.id === id ? { ...m, ...patch } : m)))
  }

  // =========================
  // SEND LOGIC (unchanged core)
  // =========================
  const send = useCallback(async () => {
    const text = input.trim()
    if (!text || loading) return

    setInput('')
    setLoading(true)
    if (inputRef.current) inputRef.current.style.height = 'auto'

    addMessage({ role: 'user', content: text })

    // Deep research
    if (settings.depth === 'deep') {
      const assistantId = addMessage({
        role: 'assistant',
        content: 'Running deep research…',
        isStreaming: true,
      })

      try {
        const report = await runResearch(
          text,
          settings.mode,
          fileAnalysis?.file_id,
          settings.sessionId
        )

        updateMessage(assistantId, {
          content: report.executive_summary,
          report,
          citations: report.all_citations,
          confidence: report.overall_confidence,
          isStreaming: false,
        })
      } catch (e) {
        updateMessage(assistantId, {
          content: `Error: ${e instanceof Error ? e.message : 'Unknown error'}`,
          isStreaming: false,
        })
      }

      setLoading(false)
      return
    }

    // Streaming
    const assistantId = addMessage({
      role: 'assistant',
      content: '',
      isStreaming: true,
    })

    abortRef.current = new AbortController()
    let streamedText = ''

    await streamChat(
      {
        session_id: settings.sessionId,
        message: text,
        mode: settings.mode,
        depth: settings.depth,
        file_id: fileAnalysis?.file_id,
      },
      {
        onToken: chunk => {
          streamedText += chunk
          updateMessage(assistantId, { content: streamedText })
        },
        onDone: event => {
          updateMessage(assistantId, {
            content: event.meta.full_text,
            citations: event.meta.citations,
            confidence: event.meta.confidence,
            isStreaming: false,
          })
          setLoading(false)
        },
        onError: msg => {
          updateMessage(assistantId, {
            content: `Error: ${msg}`,
            isStreaming: false,
          })
          setLoading(false)
        },
      },
      abortRef.current.signal
    )
  }, [input, loading, settings, fileAnalysis])

  const handleStop = () => {
    abortRef.current?.abort()
    setLoading(false)
  }

  // =========================
  // UI
  // =========================
  return (
    <div className="flex flex-col h-screen bg-slate-50">

      {/* HEADER */}
      <header className="flex items-center justify-between px-4 py-3 bg-white border-b">
        <div>
          <h1 className="text-sm font-semibold text-slate-900">
            AI Health Research
          </h1>
          <p className="text-xs text-slate-500">
            Clinical-grade AI assistant
          </p>
        </div>

        <ModeToggle
          value={settings.mode}
          onChange={mode => setSettings(s => ({ ...s, mode }))}
        />
      </header>

      {/* CHAT AREA */}
      <main className="flex-1 overflow-y-auto px-4 py-6 space-y-4">
        {messages.map(msg => (
          <MessageBubble key={msg.id} message={msg} />
        ))}
        <div ref={bottomRef} />
      </main>

      {/* INPUT AREA */}
      <div className="border-t bg-white px-4 py-3 space-y-3">

        {/* Upload */}
        {showUpload && (
          <FileUpload
            onAnalysis={a => {
              setFileAnalysis(a)
              setShowUpload(false)
            }}
            onClear={() => setFileAnalysis(null)}
            currentAnalysis={fileAnalysis}
          />
        )}

        {/* Active file */}
        {fileAnalysis && (
          <div className="text-xs bg-purple-50 border border-purple-100 px-3 py-2 rounded-md flex justify-between">
            <span>{fileAnalysis.document_type}</span>
            <button onClick={() => setFileAnalysis(null)}>×</button>
          </div>
        )}

        {/* Controls */}
        <div className="flex items-end gap-2">

          <DepthToggle
            value={settings.depth}
            onChange={depth => setSettings(s => ({ ...s, depth }))}
            disabled={loading}
          />

          <div className="flex-1 flex items-center gap-2 border rounded-xl px-3 py-2 bg-slate-50 focus-within:bg-white">

            <button onClick={() => setShowUpload(v => !v)}>
              📎
            </button>

            <textarea
              ref={inputRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              placeholder="Ask a medical question…"
              className="flex-1 bg-transparent outline-none text-sm resize-none"
            />

            {loading ? (
              <button onClick={handleStop}>■</button>
            ) : (
              <button onClick={send} disabled={!input.trim()}>
                ➤
              </button>
            )}
          </div>
        </div>
      </div>

      {/* SYSTEM FOOTER */}
      <DisclaimerBanner />
    </div>
  )
}