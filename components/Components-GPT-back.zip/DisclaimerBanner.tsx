'use client'

export function DisclaimerBanner() {
  return (
    <div className="flex items-center gap-2 px-3 py-2 text-xs text-slate-500 border-t bg-slate-50">
      <span className="text-blue-500">ℹ️</span>
      <span>
        Educational use only. Not a substitute for professional medical advice.
      </span>
    </div>
  )
}