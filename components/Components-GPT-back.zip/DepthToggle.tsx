'use client'

import type { ResearchDepth } from '@/lib/types'

interface Props {
  value: ResearchDepth
  onChange: (depth: ResearchDepth) => void
  disabled?: boolean
}

const DEPTHS: { value: ResearchDepth; label: string; desc: string; icon: string }[] = [
  { value: 'quick',  label: 'Quick',  desc: '~1s',   icon: '⚡' },
  { value: 'normal', label: 'Normal', desc: '~5s',   icon: '🔍' },
  { value: 'deep',   label: 'Deep',   desc: '~30s',  icon: '🧬' },
]

export function DepthToggle({ value, onChange, disabled }: Props) {
  return (
    <div className="flex gap-1 p-1 bg-gray-100 rounded-lg">
      {DEPTHS.map((d) => (
        <button
          key={d.value}
          onClick={() => !disabled && onChange(d.value)}
          disabled={disabled}
          className={`flex-1 px-2 py-1.5 rounded-md text-xs font-medium transition-all ${
            value === d.value
              ? 'bg-white text-gray-900 shadow-sm'
              : 'text-gray-500 hover:text-gray-700'
          } ${disabled ? 'opacity-40 cursor-not-allowed' : ''}`}
        >
          <span className="mr-1" style={{ fontSize: '10px' }}>{d.icon}</span>
          {d.label}
          <span className="text-[10px] font-normal opacity-50 ml-1 hidden sm:inline">{d.desc}</span>
        </button>
      ))}
    </div>
  )
}
