'use client'

import { useState } from 'react'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import type { Message } from '@/lib/types'
import { SourceCard } from './SourceCard'
import { ResearchPanel } from './ResearchPanel'

interface Props {
  message: Message
}

const CONFIDENCE_STYLE = {
  high: 'bg-green-50 text-green-700 border-green-200',
  medium: 'bg-amber-50 text-amber-700 border-amber-200',
  low: 'bg-gray-50 text-gray-500 border-gray-200',
}

export function MessageBubble({ message }: Props) {
  const [showSources, setShowSources] = useState(false)

  const isUser = message.role === 'user'

  // ✅ SAFE timestamp
  const date = new Date(message.timestamp)

const time =
  typeof message.timestamp === 'number'
    ? new Date(message.timestamp).toLocaleTimeString('en-GB', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
      })
    : ''

  // =========================
  // USER MESSAGE
  // =========================
  if (isUser) {
    return (
      <div className="flex justify-end px-2">
        <div className="max-w-[70%] bg-blue-600 text-white rounded-2xl rounded-tr-sm px-4 py-2.5 text-sm leading-relaxed shadow-sm">
          {message.content}
        </div>
      </div>
    )
  }

  // =========================
  // ASSISTANT MESSAGE
  // =========================
  return (
    <div className="flex gap-3 px-2 items-start">

      {/* Avatar */}
      <div className="w-7 h-7 shrink-0 rounded-full bg-gradient-to-br from-blue-500 to-teal-400 flex items-center justify-center mt-0.5 shadow-sm">
        <span className="text-white text-[15px] font-semibold">**</span>
      </div>

      <div className="flex-1 min-w-0">

        {/* MAIN CONTENT */}
        <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-sm px-4 py-3 text-sm text-slate-800 leading-relaxed shadow-sm">

          {message.report ? (
            <div className="space-y-2">
              <div className="text-[11px] font-medium text-blue-600">
                Deep Research Report
              </div>
              <ResearchPanel report={message.report} />
            </div>
          ) : (
            <>
              <div className="prose prose-sm max-w-none prose-headings:font-medium prose-a:text-blue-600">
                <ReactMarkdown remarkPlugins={[remarkGfm]}>
                  {message.content}
                </ReactMarkdown>
              </div>

              {/* Streaming cursor */}
              {message.isStreaming && (
                <span className="inline-block w-0.5 h-4 bg-slate-400 ml-0.5 animate-pulse" />
              )}
            </>
          )}
        </div>

        {/* METADATA ROW */}
        {!message.isStreaming && (
          <div className="flex items-center justify-between mt-1.5 px-1">

            <div className="flex items-center gap-2">

              {/* Confidence */}
              {message.confidence && (
                <span
                  className={`text-[10px] px-2 py-0.5 rounded border font-medium ${
                    CONFIDENCE_STYLE[
                      message.confidence as keyof typeof CONFIDENCE_STYLE
                    ] ?? CONFIDENCE_STYLE.medium
                  }`}
                >
                  {message.confidence}
                </span>
              )}

              {/* Sources toggle */}
              {message.citations && message.citations.length > 0 && !message.report && (
                <button
                  onClick={() => setShowSources(!showSources)}
                  className="text-[11px] text-slate-500 hover:text-slate-700 flex items-center gap-1"
                >
                  📚 {message.citations.length}
                </button>
              )}
            </div>

            {/* Timestamp */}
            {time && (
              <span className="text-[10px] text-slate-400">
                {time}
              </span>
            )}
          </div>
        )}

        {/* SOURCES PANEL */}
        {showSources && message.citations && message.citations.length > 0 && (
          <div className="mt-2 space-y-2 px-1 border-l-2 border-slate-200 pl-3 animate-in fade-in">
            <div className="text-[11px] text-slate-500 font-medium">
              Sources
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {message.citations.map((c, i) => (
                <SourceCard key={i} citation={c} index={i + 1} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}