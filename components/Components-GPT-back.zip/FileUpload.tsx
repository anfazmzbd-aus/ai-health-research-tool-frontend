'use client'

import { useCallback, useState } from 'react'
import type { MultimodalAnalysis } from '@/lib/types'
import { uploadFile } from '@/lib/api'

interface Props {
  onAnalysis: (analysis: MultimodalAnalysis) => void
  onClear: () => void
  currentAnalysis: MultimodalAnalysis | null
}

export function FileUpload({ onAnalysis, onClear, currentAnalysis }: Props) {
  const [dragging, setDragging] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleFile = useCallback(async (file: File) => {
    setError(null)
    setLoading(true)
    try {
      const analysis = await uploadFile(file)
      onAnalysis(analysis)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Upload failed')
    } finally {
      setLoading(false)
    }
  }, [onAnalysis])

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setDragging(false)
    const file = e.dataTransfer.files[0]
    if (file) handleFile(file)
  }, [handleFile])

  const onInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) handleFile(file)
  }

  if (currentAnalysis) {
    const abnormal = currentAnalysis.abnormal_flags.length
    return (
      <div className="border border-purple-200 bg-purple-50 rounded-lg p-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-medium uppercase tracking-wide text-purple-600">
                {currentAnalysis.document_type.replace('_', ' ')}
              </span>
              {abnormal > 0 && (
                <span className="text-[10px] font-medium px-1.5 py-0.5 bg-red-100 text-red-700 rounded border border-red-200">
                  {abnormal} abnormal
                </span>
              )}
            </div>
            <p className="text-xs text-gray-700 leading-snug">{currentAnalysis.summary}</p>
            {currentAnalysis.lab_findings.length > 0 && (
              <p className="text-[10px] text-gray-500 mt-1">
                {currentAnalysis.lab_findings.length} lab values extracted
              </p>
            )}
          </div>
          <button
            onClick={onClear}
            className="text-gray-400 hover:text-gray-600 shrink-0"
            aria-label="Remove file"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M6 18L18 6M6 6l12 12"/>
            </svg>
          </button>
        </div>
      </div>
    )
  }

  return (
    <div>
      <label
        className={`flex flex-col items-center justify-center gap-2 p-4 border-2 border-dashed rounded-lg cursor-pointer transition-colors ${
          dragging
            ? 'border-blue-400 bg-blue-50'
            : 'border-gray-200 hover:border-gray-300 bg-gray-50'
        } ${loading ? 'opacity-60 pointer-events-none' : ''}`}
        onDragOver={(e) => { e.preventDefault(); setDragging(true) }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
      >
        <input
          type="file"
          className="sr-only"
          accept=".pdf,.png,.jpg,.jpeg,.txt"
          onChange={onInputChange}
          disabled={loading}
        />
        {loading ? (
          <div className="flex items-center gap-2 text-xs text-gray-500">
            <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/>
            </svg>
            Analysing…
          </div>
        ) : (
          <>
            <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
            </svg>
            <span className="text-xs text-gray-500">
              Drop a lab report, scan or PDF
            </span>
            <span className="text-[10px] text-gray-400">PDF · PNG · JPG · TXT · up to 20 MB</span>
          </>
        )}
      </label>
      {error && (
        <p className="text-xs text-red-600 mt-1.5">{error}</p>
      )}
    </div>
  )
}
