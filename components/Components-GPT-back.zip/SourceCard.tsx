'use client'

import type { Citation } from '@/lib/types'

interface Props {
  citation: Citation
  index: number
}

const SOURCE_META: Record<string, { label: string; color: string; trust: string }> = {
  PUBMED: {
    label: 'PubMed',
    color: 'bg-blue-50 text-blue-700 border-blue-200',
    trust: 'High',
  },
  CLINICAL_TRIALS: {
    label: 'Clinical Trials',
    color: 'bg-amber-50 text-amber-700 border-amber-200',
    trust: 'High',
  },
  RAG: {
    label: 'Internal Docs',
    color: 'bg-purple-50 text-purple-700 border-purple-200',
    trust: 'Medium',
  },
  TAVILY: {
    label: 'Web Source',
    color: 'bg-teal-50 text-teal-700 border-teal-200',
    trust: 'Variable',
  },
}

function getMeta(source: string) {
  return SOURCE_META[source.toUpperCase()] ?? {
    label: source,
    color: 'bg-gray-50 text-gray-600 border-gray-200',
    trust: 'Unknown',
  }
}

function getDomain(url?: string) {
  if (!url) return null
  try {
    return new URL(url).hostname.replace('www.', '')
  } catch {
    return null
  }
}

function RelevanceBar({ score }: { score: number }) {
  const pct = Math.round(score * 100)

  const label =
    pct >= 75 ? 'Highly relevant' :
    pct >= 50 ? 'Moderately relevant' :
    'Low relevance'

  const color =
    pct >= 75 ? 'bg-green-400' :
    pct >= 50 ? 'bg-amber-400' :
    'bg-gray-300'

  return (
    <div className="space-y-0.5">
      <div className="flex items-center justify-between text-[10px] text-gray-400">
        <span>{label}</span>
        <span>{pct}%</span>
      </div>
      <div className="h-1 bg-gray-100 rounded-full overflow-hidden">
        <div className={`h-full ${color}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  )
}

export function SourceCard({ citation, index }: Props) {
  const meta = getMeta(citation.source)
  const domain = getDomain(citation.url)

  return (
    <a
      href={citation.url || '#'}
      target="_blank"
      rel="noopener noreferrer"
      className="block border border-gray-100 rounded-xl p-3 bg-white hover:border-gray-300 hover:shadow-sm transition-all"
    >
      {/* Top row */}
      <div className="flex items-center justify-between mb-2">
        <span className="text-[10px] text-gray-400 font-mono">
          [{index}]
        </span>

        <div className="flex items-center gap-1.5">
          <span className={`text-[10px] px-1.5 py-0.5 rounded border font-medium ${meta.color}`}>
            {meta.label}
          </span>
          <span className="text-[10px] text-gray-400">
            {meta.trust}
          </span>
        </div>
      </div>

      {/* Title */}
      <div className="text-xs font-semibold text-gray-900 leading-snug mb-1">
        {citation.title}
        {citation.year && (
          <span className="ml-1 text-gray-400 font-normal">
            ({citation.year})
          </span>
        )}
      </div>

      {/* Preview */}
      {citation.chunk_preview && (
        <div className="text-[11px] text-gray-500 leading-relaxed line-clamp-2 mb-2">
          {citation.chunk_preview}
        </div>
      )}

      {/* Relevance */}
      <RelevanceBar score={citation.relevance_score} />

      {/* Footer */}
      {domain && (
        <div className="mt-2 text-[10px] text-gray-400 truncate">
          {domain}
        </div>
      )}
    </a>
  )
}