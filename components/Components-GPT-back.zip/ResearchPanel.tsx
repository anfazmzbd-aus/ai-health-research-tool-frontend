'use client'

import { useState } from 'react'
import type { ResearchReport } from '@/lib/types'
import { SourceCard } from './SourceCard'

interface Props {
  report: ResearchReport
}

const GRADE_STYLE = {
  high: 'bg-green-50 text-green-700 border-green-200',
  medium: 'bg-amber-50 text-amber-700 border-amber-200',
  low: 'bg-gray-50 text-gray-500 border-gray-200',
}

function Section({
  title,
  children,
  defaultOpen = true,
}: {
  title: string
  children: React.ReactNode
  defaultOpen?: boolean
}) {
  const [open, setOpen] = useState(defaultOpen)

  return (
    <div className="border border-slate-200 rounded-xl overflow-hidden bg-white">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between px-4 py-3 bg-slate-50 hover:bg-slate-100 text-left"
      >
        <span className="text-sm font-medium text-slate-700">{title}</span>
        <span className="text-xs text-slate-400">{open ? '−' : '+'}</span>
      </button>

      {open && <div className="px-4 py-4">{children}</div>}
    </div>
  )
}

export function ResearchPanel({ report }: Props) {
  const elapsed = (report.research_time_ms / 1000).toFixed(1)

  return (
    <div className="space-y-4">

      {/* ===== HEADER (INTELLIGENCE SUMMARY) ===== */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs flex flex-wrap gap-3">
        <span>⏱ {elapsed}s</span>
        <span>📚 {report.total_sources_found} sources</span>
        <span className="font-medium">
          Confidence: {report.overall_confidence}
        </span>
      </div>

      {/* ===== EXECUTIVE SUMMARY (MOST IMPORTANT) ===== */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
        <div className="text-xs text-blue-600 font-medium mb-1">
          Key Insight
        </div>
        <p className="text-sm text-slate-800 leading-relaxed">
          {report.executive_summary}
        </p>
      </div>

      {/* ===== SUB QUESTIONS ===== */}
      {report.sub_questions.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {report.sub_questions.map((q, i) => (
            <span
              key={i}
              className="text-[11px] px-2 py-1 bg-blue-50 text-blue-700 rounded-full border border-blue-100"
            >
              {q.length > 60 ? q.slice(0, 60) + '…' : q}
            </span>
          ))}
        </div>
      )}

      {/* ===== FINDINGS ===== */}
      {report.detailed_findings.length > 0 && (
        <Section title="Evidence Breakdown">
          <div className="space-y-3">
            {report.detailed_findings.map((f, i) => (
              <div
                key={i}
                className="border border-slate-200 rounded-lg p-3 bg-slate-50"
              >
                <div className="flex items-center gap-2 mb-1">
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded border font-medium ${
                      GRADE_STYLE[f.evidence_grade]
                    }`}
                  >
                    {f.evidence_grade}
                  </span>

                  <span className="text-xs font-medium text-slate-700">
                    {f.question}
                  </span>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">
                  {f.answer}
                </p>
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* ===== CLINICAL IMPLICATIONS ===== */}
      {report.clinical_implications && (
        <Section title="Clinical Interpretation">
          <p className="text-sm text-slate-700 leading-relaxed">
            {report.clinical_implications}
          </p>
        </Section>
      )}

      {/* ===== LIMITATIONS ===== */}
      {report.limitations && (
        <Section title="Limitations" defaultOpen={false}>
          <p className="text-sm text-slate-500 leading-relaxed">
            {report.limitations}
          </p>
        </Section>
      )}

      {/* ===== SOURCES ===== */}
      {report.all_citations.length > 0 && (
        <Section title={`Sources (${report.all_citations.length})`} defaultOpen={false}>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {report.all_citations.map((c, i) => (
              <SourceCard key={i} citation={c} index={i + 1} />
            ))}
          </div>
        </Section>
      )}

      {/* ===== DISCLAIMER ===== */}
      <div className="text-[11px] text-amber-700 bg-amber-50 border border-amber-100 rounded-md px-3 py-2">
        ⚠️ {report.disclaimer}
      </div>
    </div>
  )
}